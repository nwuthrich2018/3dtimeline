﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class onItemSelect : MonoBehaviour {

	// Use this for initialization
	void Start () {
		//Debug.Log("Loaded");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
		

	void OnMouseDown()
	{
		Application.LoadLevel("DetailScreen");
		Debug.Log("It Works");
	}
}
